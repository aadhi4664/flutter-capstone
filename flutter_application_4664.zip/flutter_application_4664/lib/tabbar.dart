import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Explore extends StatefulWidget {
  const Explore({super.key});

  @override
  State<Explore> createState() => _TabbarState();
}

class _TabbarState extends State<Explore> {
   final List<String> players = [
    'assets/images/image 5.jpg',
    'assets/images/image 6.jpg',
    'assets/images/image 7.jpg',
    'assets/images/image 8.jpg',
    'assets/images/image 9.jpg',
 ];
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(initialIndex:1 ,length: 2, child: Scaffold(
       appBar: AppBar(
        bottom: const TabBar(
          tabs: [
            Tab(icon: Icon(Icons.image)),
           
            Tab(icon: Icon(Icons.download)),
            
          ],
        ),
      ),
      body: TabBarView(children: <Widget>[
        Center(child: Text('Images are Here')),
       
       Column(
         children: [Text('DOWNLOAD WALLPAPERS',style: TextStyle(fontWeight: FontWeight.bold,fontSize: 25,color: Color.fromARGB(255, 25, 50, 0)),),
         SizedBox(height: 10,),
           CarouselSlider.builder(itemCount: players.length, itemBuilder: (context,index,rc){
            return Container(
              child: Image.asset(players[index]),
            );
           }, options: CarouselOptions(height: 400,autoPlay: true)),
         ],
       )
      ]),
    ));
  }
}